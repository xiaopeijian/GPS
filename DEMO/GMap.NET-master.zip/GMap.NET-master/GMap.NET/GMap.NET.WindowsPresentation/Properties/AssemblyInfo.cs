﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("GMap.NET.WindowsPresentation")]
[assembly: AssemblyDescription("GMap.NET - Maps for Windows Presentation")]
[assembly: AssemblyProduct("GMap.NET.WindowsPresentation")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("BB3E880B-18D8-4843-A2C1-47DC7CCC054C")]