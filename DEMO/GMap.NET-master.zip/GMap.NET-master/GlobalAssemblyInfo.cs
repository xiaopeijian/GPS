using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCompany("MainSoft Technology")]
[assembly: AssemblyCopyright("Copyright � 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyConfiguration("")]

// Las siguientes 3 declaraciones depender�n de la pol�tica de versionamiento que adopte para cada uno de los assemblies generados.
[assembly: AssemblyVersion("1.9.2.0")]
[assembly: AssemblyFileVersion("1.9.2.0")]
[assembly: AssemblyInformationalVersion("1.9.2.0")]

// Si establece ComVisible en false, los tipos de este ensamblado no estar�n visibles 
// para los componentes COM.  Si necesita obtener acceso a un tipo de este ensamblado desde 
// COM, establezca el atributo ComVisible en true en este tipo.
[assembly: ComVisible(true)]

//[assembly: ThemeInfo(
//    ResourceDictionaryLocation.None, //where theme specific resource dictionaries are located
//                                     //(used if a resource is not found in the page, 
//                                     // or application resource dictionaries)
//    ResourceDictionaryLocation.SourceAssembly //where the generic resource dictionary is located
//                                              //(used if a resource is not found in the page, 
//                                              // app, or any theme specific resource dictionaries)
//)]


