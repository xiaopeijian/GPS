using System;
namespace BackMaker
{
	public class UsageException : Exception
	{
	}
}
