using System;
namespace MSR.CVE.BackMaker.ImagePipeline
{
	public class InsufficientCorrespondencesException : Exception
	{
	}
}
