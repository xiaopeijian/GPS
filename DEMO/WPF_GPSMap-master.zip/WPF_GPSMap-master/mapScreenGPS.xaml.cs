using System.Windows;
using System.IO.Ports;
using Ghostware.NMEAParser;
using Ghostware.NMEAParser.Enums;
using Ghostware.NMEAParser.NMEAMessages;
using Microsoft.Maps.MapControl.WPF;

namespace ProjectNamespace
{
    public partial class GpsMapScreen : Window
    {
        SerialPort gpsSerial = new SerialPort();
        InternetAvailability internetConnection = new InternetAvailability();
        private double latitude = 0;
        private double longitude = 0;
        private string driverName = "Prolific";  // Default GPS driver
        private int baud = 4800;    // Default baud rate

          
        public GpsMapScreen()
        {
            InitializeComponent();
        }
        public GpsMapScreen(string driver, int baudrate)
        {
            InitializeComponent();
            driverName = driver;
            baud = baudrate;
        }
        private void CenterToLocation(Location loc, int zoom)
        {
            Dispatcher.Invoke(() =>
            {             
                gpsMap.SetView(loc, zoom);
                locationPin.Location = loc;
                locationPin.Visibility = Visibility.Visible;                          
            });         
        }
        public bool InitGPSModule()
        {
            // Detect and initialize GPS module
            UsbDriverSearch searcher = new UsbDriverSearch();
            var portName = searcher.FindDriverPort(driverName);
            if(portName != null)
            {
                gpsSerial.BaudRate = baud;
                gpsSerial.Parity = Parity.None;
                gpsSerial.StopBits = StopBits.One;
                gpsSerial.DataBits = 8;
                gpsSerial.Handshake = Handshake.None;
                gpsSerial.RtsEnable = true;
                gpsSerial.DataReceived += new SerialDataReceivedEventHandler(GpsSerialDataRecieved);
                gpsSerial.PortName = portName;
                try
                {
                    gpsSerial.Open();
                }
                catch
                {
                    return false;
                }              
                return true;
            }
            return false;
        }
        public void DisableGpsModule()
        {
            //  TODO: Handle exceptions here if needed...
            gpsSerial.Close();
        }
        // Event handlers
        private void GpsSerialDataRecieved(object sender, SerialDataReceivedEventArgs e)
        {
            NmeaParser parser = new NmeaParser();
            var gpsLine = gpsSerial.ReadLine();
            try
            {
                var result = parser.Parse(gpsLine);
                if (result.GetType() == typeof(GpggaMessage))
                {
                    var message = (GpggaMessage)result;
                    if (message.FixQuality == GpsFixQuality.GpsFix && 
                        message.Latitude != latitude && 
                        message.Longitude != longitude)
                    {
                        latitude = message.Latitude;
                        longitude = message.Longitude;
                        CenterToLocation(new Location(latitude, longitude), 16);
                    }
                }
            }
            catch
            {
                //  TODO: Handle exceptions here if needed...
                return;
            }
        }
    }
}
