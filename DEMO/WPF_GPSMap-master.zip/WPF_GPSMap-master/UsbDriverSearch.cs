﻿using System.Collections.Generic;
using System.Management;
using System.IO.Ports;

namespace ProjectNamespace
{
    class UsbDriverSearch
    {
        private class USBDeviceInfo
        {
            public USBDeviceInfo(string name, string caption, string description)
            {
                this.Name = name;
                this.Caption = caption;
                this.Description = description;
            }
            public string Name { get; private set; }
            public string Caption { get; private set; }
            public string Description { get; private set; }
        }
        private static List<USBDeviceInfo> GetUSBDevices()
        {
            List<USBDeviceInfo> devices = new List<USBDeviceInfo>();

            ManagementObjectCollection collection;
            using (var searcher = new ManagementObjectSearcher(@"Select * From Win32_PnPEntity"))
                collection = searcher.Get();

            foreach (var device in collection)
            {
                devices.Add(new USBDeviceInfo(
                (string)device.GetPropertyValue("Name"),
                (string)device.GetPropertyValue("Caption"),
                (string)device.GetPropertyValue("Description")
                ));
            }

            collection.Dispose();
            return devices;
        }
        // Search for a string in active USB drivers, return null if not available
        public string FindDriverPort(string name)
        {
            var usbDevices = GetUSBDevices();

            foreach (var usbDevice in usbDevices)
            {
                if (usbDevice.Name != null && usbDevice.Name.Contains(name))
                {
                    // Get COM number from caption or name
                    foreach (var portName in SerialPort.GetPortNames())
                    {
                        if (usbDevice.Name != null && usbDevice.Name.Contains(portName))
                        {
                            return portName;
                        }
                    }
                }
            }
            return null;
        }
    }
}
