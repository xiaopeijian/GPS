# WPF_GPSMap
Simple GPS tracking window class for WPF applications. The class tracks the movement of a USB GPS antenna and visualizes on the window using Bing Maps API.

Dependencies:
- Ghostware.NMEAParser
